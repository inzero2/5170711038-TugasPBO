package manusia;

public class OrangTua {

    void keriting() {
        System.out.println("Keriting");
    }

    void gelombang() {
        System.out.println("Menggelombang");
    }

    void sawo() {
        System.out.println("Sawo matang");
    }

    void langsat() {
        System.out.println("Kuning langsat");
    }

    void tinggi() {
        System.out.println("180 cm");
    }

    void pendek() {
        System.out.println("150 cm");
    }
}
