package manusia;

public class Anak3 extends OrangTua {

    void rambut() {
        System.out.print("Jenis rambut: ");
    }

    void kulit() {
        System.out.print("Warna kulit: ");
    }

    void tinggibdn() {
        System.out.print("Tinggi badan: ");
    }

}
